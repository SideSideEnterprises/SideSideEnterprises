<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/comparison-slider/cmp-slider.php';