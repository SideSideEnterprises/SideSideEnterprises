<div class="comparison-slider" <?php echo topfit_mikado_get_inline_attrs($data_attrs); ?>>
	<?php echo wp_get_attachment_image($image_before, 'full'); ?>
	<?php echo wp_get_attachment_image($image_after, 'full'); ?>
</div>