<div <?php topfit_mikado_class_attribute($holder_classes); ?> <?php topfit_mikado_inline_style($styles); ?>>
	<div class="mkd-card-slider" <?php echo topfit_mikado_get_inline_attrs($data_attrs); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>