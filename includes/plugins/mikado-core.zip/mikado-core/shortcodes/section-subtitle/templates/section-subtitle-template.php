<div <?php topfit_mikado_class_attribute($classes); ?> <?php topfit_mikado_inline_style($holder_styles); ?>>
	<p <?php topfit_mikado_inline_style($styles); ?> class="mkd-section-subtitle"><?php echo wp_kses_post($text); ?></p>
</div>