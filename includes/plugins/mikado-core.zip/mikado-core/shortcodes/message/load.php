<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/message/message.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/message/custom-styles/message.php';