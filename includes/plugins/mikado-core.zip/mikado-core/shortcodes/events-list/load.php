<?php

if(topfit_mikado_the_events_calendar_installed()) {
    include_once MIKADO_CORE_ABS_PATH.'/shortcodes/events-list/events-list.php';

//	function test() {
//		$shortcode_loader = \TopFit\Modules\Shortcodes\Lib\ShortcodeLoader::getInstance();
//
//		$shortcode_loader->addShortcode(new \TopFit\Modules\Shortcodes\EventsList\EventsList());
//	}
//
//	add_action('topfit_mikado_before_shortcodes_load', 'test');
}

