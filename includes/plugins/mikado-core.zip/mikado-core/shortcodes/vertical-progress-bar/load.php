<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/vertical-progress-bar/vertical-progress-bar.php';