<div <?php topfit_mikado_class_attribute($holder_classes); ?> <?php topfit_mikado_inline_style($element_styles); ?>>
	<div class="mkd-iwt-icon-holder">
		<?php if (!empty($custom_icon)) : ?>
			<span
				class="mkd-iwt-custom-icon" <?php topfit_mikado_inline_style($custom_icon_styles); ?>><?php echo wp_get_attachment_image($custom_icon, 'full'); ?></span>
		<?php else: ?>
			<?php echo mikado_core_get_core_shortcode_template_part('templates/icon', 'icon-with-text', '', array('icon_parameters' => $icon_parameters)); ?>
		<?php endif; ?>
	</div>
	<div class="mkd-iwt-content-holder" <?php topfit_mikado_inline_style($content_styles); ?>>
		<?php if ($title != ''){ ?>
		<div class="mkd-iwt-title-holder">
			<<?php echo esc_attr($title_tag); ?>
			class="mkd-iwt-title" <?php topfit_mikado_inline_style($title_styles); ?>
			><?php echo esc_html($title); ?></<?php echo esc_attr($title_tag); ?>>
	</div>
	<?php } ?>
	<div class="mkd-iwt-text-holder">
		<p <?php topfit_mikado_inline_style($text_styles); ?>><?php echo esc_html($text); ?></p>

		<?php
		if (!empty($link) && !empty($link_text)) :
			echo topfit_mikado_get_button_html($button_parameters);
		endif;
		?>
	</div>
</div>
</div>