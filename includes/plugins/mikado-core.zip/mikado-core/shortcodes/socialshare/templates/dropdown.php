<div class="mkd-social-share-holder mkd-dropdown">
	<a href="javascript:void(0)" target="_self" class="mkd-social-share-dropdown-opener">
		<i class="icon-share-alt"></i>
	</a>

	<div class="mkd-social-share-dropdown">
		<ul>
			<?php foreach($networks as $net) {
                echo topfit_mikado_get_module_part($net);

			} ?>
		</ul>
	</div>
</div>