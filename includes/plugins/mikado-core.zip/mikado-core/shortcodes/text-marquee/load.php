<?php
include_once MIKADO_CORE_ABS_PATH . '/shortcodes/text-marquee/text-marquee.php';