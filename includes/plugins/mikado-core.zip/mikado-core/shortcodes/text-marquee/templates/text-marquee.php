<div class="mkd-text-marquee">
    <div class="mkd-text-marquee-wrapper">
        <span class="mkd-text-marquee-title" style="<?php echo esc_attr($title_style); ?>"><?php echo esc_attr($title); ?></span>
        <span class="mkd-text-marquee-title mkd-aux-text" style="<?php echo esc_attr($title_style); ?>"><?php echo esc_attr($title); ?></span>
    </div>
</div>