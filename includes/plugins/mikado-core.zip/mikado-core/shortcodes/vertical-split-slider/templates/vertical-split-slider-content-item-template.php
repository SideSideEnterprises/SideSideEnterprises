<div class="mkd-vss-ms-section" <?php topfit_mikado_inline_style($content_style);?> <?php echo topfit_mikado_get_inline_attrs($content_data); ?>>
	<?php echo do_shortcode($content); ?>
</div>