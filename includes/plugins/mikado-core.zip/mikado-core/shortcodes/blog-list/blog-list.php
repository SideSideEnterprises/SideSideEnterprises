<?php

namespace TopFit\Modules\BlogList;

use TopFit\Modules\Shortcodes\Lib\ShortcodeInterface;

/**
 * Class BlogList
 */
class BlogList implements ShortcodeInterface {
	/**
	 * @var string
	 */
	private $base;

	function __construct() {
		$this->base = 'mkd_blog_list';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {

		vc_map(array(
			'name'                      => esc_html__('Blog List', 'mikado-core'),
			'base'                      => $this->base,
			'icon'                      => 'icon-wpb-blog-list extended-custom-icon',
			'category' => esc_html__( 'by MIKADO', 'mikado-core' ),
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Type', 'mikado-core'),
					'param_name'  => 'type',
					'value'       => array(
						esc_html__('Minimal', 'mikado-core')      => 'minimal',
						esc_html__('Simple', 'mikado-core')       => 'simple',
						esc_html__('Masonry', 'mikado-core')      => 'masonry',
						esc_html__('Image in box', 'mikado-core') => 'image-in-box'
					),
					'description' => '',
					'save_always' => true
				),
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__('Columns', 'mikado-core'),
					'param_name'  => 'masonry_columns',
					'description' => '',
					'value'       => array(
						'3' => '3',
						'4' => '4',
					),
					'dependency'  => array(
						'element' => 'type',
						'value'   => 'masonry'
					),
					'save_always' => true
				),
				array(
					'type'        => 'checkbox',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Simple boxed', 'mikado-core'),
					'param_name'  => 'simple_boxed',
					'dependency'  => array(
						'element' => 'type',
						'value'   => 'simple'
					),
					'description' => ''
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Skin', 'mikado-core'),
					'param_name'  => 'skin',
					'value'       => array(
						esc_html__('Light', 'mikado-core') => 'light',
						esc_html__('Dark', 'mikado-core')  => 'dark'
					),
					'dependency'  => array(
						'element'   => 'simple_boxed',
						'not_empty' => true
					),
					'description' => '',
					'save_always' => true
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Number of Posts', 'mikado-core'),
					'param_name'  => 'number_of_posts',
					'description' => ''
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Order By', 'mikado-core'),
					'param_name'  => 'order_by',
					'value'       => array(
						esc_html__('Title', 'mikado-core') => 'title',
						esc_html__('Date', 'mikado-core')  => 'date'
					),
					'save_always' => true,
					'description' => ''
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Order', 'mikado-core'),
					'param_name'  => 'order',
					'value'       => array(
						esc_html__('ASC', 'mikado-core')  => 'ASC',
						esc_html__('DESC', 'mikado-core') => 'DESC'
					),
					'save_always' => true,
					'description' => ''
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Category Slug', 'mikado-core'),
					'param_name'  => 'category',
					'description' => esc_html__('Leave empty for all or use comma for list', 'mikado-core')
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__('Text length', 'mikado-core'),
					'param_name'  => 'text_length',
					'description' => esc_html__('Number of characters', 'mikado-core'),
					'dependency'  => array(
						'element' => 'type',
						'value'   => array('minimal', 'simple', 'image-in-box')
					),
				)
			)
		));

	}

	public function render($atts, $content = null) {

		$default_atts = array(
			'type'            => 'minimal',
			'masonry_columns' => '3',
			'simple_boxed'    => '',
			'skin'            => '',
			'number_of_posts' => '',
			'order_by'        => '',
			'order'           => '',
			'category'        => '',
			'text_length'     => '90',
		);

		$params = shortcode_atts($default_atts, $atts);
		$params['holder_classes'] = $this->getBlogHolderClasses($params);


		$queryArray = $this->generateBlogQueryArray($params);
		$query_result = new \WP_Query($queryArray);
		$params['query_result'] = $query_result;

		$html = '';
		$html .= mikado_core_get_core_shortcode_template_part('templates/blog-list-holder', 'blog-list', '', $params);

		return $html;

	}

	/**
	 * Generates holder classes
	 *
	 * @param $params
	 *
	 * @return string
	 */
	private function getBlogHolderClasses($params) {
		$holderClasses = array(
			'mkd-blog-list-holder',
			'mkd-' . $params['type'],
		);

		if ($params['type'] === 'simple' && $params['simple_boxed']) {
			$holderClasses[] = 'boxed';
		}

		if ($params['type'] === 'masonry') {
			if($params['masonry_columns'] == '4') {
				$holderClasses[] = 'mkd-four';
			}
			else {
				$holderClasses[] = 'mkd-three';
			}
		}


		if ($params['skin'] !== '') {
			$holderClasses[] = $params['skin'];
		}

		return $holderClasses;

	}

	/**
	 * Generates query array
	 *
	 * @param $params
	 *
	 * @return array
	 */
	public function generateBlogQueryArray($params) {

		$queryArray = array(
			'orderby'        => $params['order_by'],
			'order'          => $params['order'],
			'posts_per_page' => $params['number_of_posts'],
			'category_name'  => $params['category']
		);

		return $queryArray;
	}
}
