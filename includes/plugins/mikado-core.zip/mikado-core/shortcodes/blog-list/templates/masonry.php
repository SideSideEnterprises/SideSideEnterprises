<?php

topfit_mikado_get_post_format_html('masonry');