<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/blockquote/options-map/map.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/blockquote/blockquote.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/blockquote/custom-styles/blockquote.php';