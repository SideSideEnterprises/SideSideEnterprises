<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/calltoaction/options-map/map.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/calltoaction/call-to-action.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/calltoaction/custom-styles/call-to-action.php';