<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to topfit_mikado_style_dynamic hook
 */

//if (!function_exists('topfit_mikado_counter_style')) {
//
//	function topfit_mikado_counter_style()
//	{
//
//		if (topfit_mikado_options()->getOptionValue('option_value') !== '') {
//			echo topfit_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => topfit_mikado_filter_px(topfit_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('topfit_mikado_style_dynamic', 'topfit_mikado_counter_style');
//
//}

?>