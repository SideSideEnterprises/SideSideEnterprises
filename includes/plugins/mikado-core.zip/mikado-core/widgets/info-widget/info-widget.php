<?php

class TopFitMikadoInfoWidget extends TopFitMikadoWidget {
	public function __construct() {
		parent::__construct(
			'mkd_info_widget', // Base ID
			esc_html__('Info Widget', 'mikado-core') // Name
		);

		$this->setParams();
	}

	protected function setParams() {
		$this->params = array(
			array(
				'name'  => 'title',
				'type'  => 'textfield',
				'title' => esc_html__('Title', 'mikado-core')
			),
			array(
				'name'  => 'text',
				'type'  => 'textarea',
				'title' => esc_html__('Text', 'mikado-core')
			),
			array(
				'name'  => 'phone_number',
				'type'  => 'textfield',
				'title' => esc_html__('Phone number', 'mikado-core')
			)
		);
	}

	public function widget($args, $instance) {
        echo topfit_mikado_get_module_part($args['before_widget']);

		if (!empty($instance['title'])) {
            echo topfit_mikado_get_module_part($args['before_title'] . $instance['title'] . $args['after_title']);
		} ?>

		<p class="mkd-info-text">
			<?php echo topfit_mikado_get_module_part($instance['text']); ?>
		</p>

		<p class="mkd-info-phone">
			<span aria-hidden="true" class="mkd-icon-font-elegant icon_phone "></span>
			<a href="tel:<?php echo topfit_mikado_get_module_part($instance['phone_number']) ?>">
				<?php echo topfit_mikado_get_module_part($instance['phone_number']); ?>
			</a>
		</p>

		<?php echo topfit_mikado_get_module_part($args['after_widget']);
	}

}