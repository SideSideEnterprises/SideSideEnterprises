<?php

require_once MIKADO_CORE_ABS_PATH.'/widgets/latest-post/latest-posts.php';