<?php

require_once MIKADO_CORE_ABS_PATH.'/widgets/search-opener/search-opener.php';
