<?php

if(topfit_mikado_is_plugin_installed('woocommerce')) {
    require_once MIKADO_CORE_ABS_PATH . '/widgets/woocommerce-dropdown-cart/woocommerce-dropdown-cart.php';
}