<?php

define('MIKADOF_BMI_CALCULATOR_VERSION', '1.0');
define('MIKADO_BMI_CALCULATOR_ABS_PATH', dirname(__FILE__));
define('MIKADO_BMI_CALCULATOR_REL_PATH', dirname(plugin_basename(__FILE__ )));