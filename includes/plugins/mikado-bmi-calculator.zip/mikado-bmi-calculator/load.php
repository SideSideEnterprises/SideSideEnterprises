<?php

require_once 'const.php';
require_once 'helpers.php';
require_once 'functions.php';

//load lib
require_once 'lib/shortcode-interface.php';
require_once 'lib/bmi-calculator-api.php';

//load shortcodes
require_once 'shortcodes/bmi-calculator-form/bmi-calculator-form.php';

//load shortcodes inteface
require_once 'lib/shortcode-loader.php';
